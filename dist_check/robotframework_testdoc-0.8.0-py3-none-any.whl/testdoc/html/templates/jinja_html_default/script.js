/**
 * Robot Framework TestDoc — main UI script
 *
 * Responsibilities:
 *  - Navigation: mark active tree items, expand/collapse branches
 *  - Suite filtering: show only the selected suite block in the content area
 *  - Test highlighting: highlight a test block when clicked or navigated to
 *  - Lazy rendering: defer mounting heavy test-block content until it enters the viewport
 *  - Code toggle: collapse / expand Robot Framework code sections
 *  - RF syntax highlight: client-side highlight for `pre.rf-code` elements (fallback)
 */

document.addEventListener('DOMContentLoaded', function () {

    /* =========================================================
       Small UI toggles (theme + sidebar)
       ========================================================= */

    (function setupThemeToggle() {
        const btn = document.getElementById('themeToggle');
        if (!btn) return;
        btn.addEventListener('click', function () {
            const html = document.documentElement;
            const isDark = html.getAttribute('data-theme') === 'dark';
            const next = isDark ? 'light' : 'dark';
            html.setAttribute('data-theme', next);
            try { localStorage.setItem('clarity-theme', next); } catch (e) {}
        });
    })();

    (function setupSidebarToggle() {
        const btn = document.getElementById('sidebarToggle');
        const sidebar = document.getElementById('sidebar');
        if (!btn || !sidebar) return;
        btn.addEventListener('click', function () {
            sidebar.classList.toggle('collapsed');
        });
    })();

    (function setupPrimaryNavigation() {
        const dashboardButton = document.getElementById('sidebarDashboard');
        const repositoryButton = document.getElementById('sidebarRepository');
        const dashboardToggle = document.getElementById('dashboardToggle');
        const firstSuite = document.querySelector('.tree-suite');
        if (!dashboardButton || !repositoryButton || !dashboardToggle) return;

        dashboardButton.addEventListener('click', function () {
            if (!dashboardToggle.classList.contains('active')) dashboardToggle.click();
            dashboardButton.classList.add('active');
            repositoryButton.classList.remove('active');
        });

        repositoryButton.addEventListener('click', function () {
            if (dashboardToggle.classList.contains('active')) dashboardToggle.click();
            if (firstSuite) firstSuite.click();
            repositoryButton.classList.add('active');
            dashboardButton.classList.remove('active');
        });
    })();

    /* =========================================================
       Element references
       ========================================================= */
    const navRoot     = document.querySelector('.nav-tree');
    const suiteBlocks = document.querySelectorAll('.suite-block');

    // test blocks are re-queried after each suite change (lazy rendering updates the DOM)
    let testBlocks = document.querySelectorAll('.test-block[id^="test-"]');

    /* =========================================================
       Lazy rendering
       ========================================================= */
    const LAZY_PREFILL = 20;
    let intersectionObserver;

    /** Mount a lazily prepared test block by moving its <template> content into the DOM. */
    function mountBlock(block) {
        if (block.dataset.mounted === '1') return;
        const tpl = block.querySelector('template.lazy-tpl');
        if (tpl) {
            block.appendChild(tpl.content.cloneNode(true));
            block.querySelectorAll('pre.rf-code').forEach(highlightRfPre);
            block.querySelectorAll('pre.robotframework').forEach(addLineNumbers);
            block.dataset.mounted = '1';
            // Restore collapsed state on the body container
            if (block.classList.contains('collapsed')) {
                const body = block.querySelector('.test-body-collapsible');
                if (body) body.style.display = 'none';
            }
            // Collapse all code sections inside the newly mounted block
            block.querySelectorAll('.code-wrapper').forEach(function (wrapper) {
                wrapper.classList.add('collapsed');
                const codeBody = wrapper.querySelector('.code-toggle-body');
                if (codeBody) codeBody.style.display = 'none';
            });
            block.querySelectorAll('.code-toggle').forEach(function (toggle) {
                toggle.classList.add('collapsed');
            });
        }
    }

    /**
     * For the currently visible suite, wrap each test block's heavy sub-sections
     * in a <template> and observe them for intersection-based mounting.
     */
    function prepareLazyRenderingForCurrentSuite() {
        if (intersectionObserver) intersectionObserver.disconnect();

        intersectionObserver = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    mountBlock(entry.target);
                    intersectionObserver.unobserve(entry.target);
                }
            });
        }, { root: null, rootMargin: '200px', threshold: 0.01 });

        // Only consider test blocks inside the currently visible suite
        testBlocks = document.querySelectorAll('.suite-block:not([style*="display: none"]) .test-block[id^="test-"]');

        let index = 0;
        testBlocks.forEach(function (block) {
            // Skip already prepared / mounted blocks
            if (block.dataset.prepared === '1' || block.dataset.mounted === '1') {
                if (block.dataset.mounted === '1') {
                    block.querySelectorAll('pre.rf-code').forEach(highlightRfPre);
                }
                return;
            }

            // Move the collapsible body container into a <template> for deferred rendering
            const collapsibleBody = block.querySelector('.test-body-collapsible');
            if (collapsibleBody) {
                const tpl = document.createElement('template');
                tpl.classList.add('lazy-tpl');
                tpl.content.appendChild(collapsibleBody);
                block.appendChild(tpl);
            }
            block.dataset.prepared = '1';

            if (index < LAZY_PREFILL) {
                mountBlock(block);
            } else {
                intersectionObserver.observe(block);
            }
            index++;
        });
    }

    /* =========================================================
       Suite filtering & navigation
       ========================================================= */

    /** Show only the suite block matching `selectedSuiteId`, hide all others. */
    function applySuiteFilter(selectedSuiteId) {
        if (!selectedSuiteId) return;
        suiteBlocks.forEach(function (block) {
            block.style.display = (block.dataset.suiteId === selectedSuiteId) ? '' : 'none';
        });
    }

    /**
     * Scroll to the element with `targetId`.
     * If `isTest` is true, also highlight the corresponding test block.
     */
    function scrollToTarget(targetId, isTest) {
        if (!targetId) return;
        const el = document.getElementById(targetId);
        if (!el) return;

        el.scrollIntoView({ behavior: 'smooth', block: 'start' });

        if (isTest) {
            clearTestHighlight();
            el.classList.add('highlighted');
        }
    }

    /**
     * Find the closest .tree-children UL for a suite link's <li> parent,
     * also handling the root-level sibling case.
     */
    function findChildUl(link) {
        const li = link.closest('li');
        if (!li) return null;

        const direct = Array.from(li.children).find(function (el) {
            return el.classList && el.classList.contains('tree-children');
        });
        if (direct) return direct;

        const sib = li.nextElementSibling;
        if (sib && sib.classList && sib.classList.contains('tree-children')) {
            return sib;
        }
        return null;
    }

    function setActiveTreeLink(activeLink) {
        if (!navRoot) return;
        navRoot.querySelectorAll('.tree-suite.active, .tree-test.active').forEach(function (l) {
            l.classList.remove('active');
        });
        if (activeLink) activeLink.classList.add('active');
    }

    function setBranchExpanded(link, expanded) {
        const li = link.closest('li');
        if (!li) return;

        const childUl = findChildUl(link);
        if (!childUl) return;

        li.classList.toggle('expanded', expanded);
        childUl.hidden = !expanded;
        link.setAttribute('aria-expanded', String(!!expanded));
    }

    /* =========================================================
       Statistics Dashboard
       ========================================================= */

    function escHtml(s) {
        return String(s).replace(/[&<>"']/g, function (c) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
        });
    }

    function dbCard(label, value, colorClass, tooltip) {
        var hintHtml = tooltip
            ? ' <span class="db-card-hint" aria-label="' + escHtml(tooltip) + '" data-tooltip="' + escHtml(tooltip) + '">?</span>'
            : '';
        return '<div class="db-card db-card-' + colorClass + '">' +
            '<div class="db-card-value">' + value + '</div>' +
            '<div class="db-card-label">' + label + hintHtml + '</div>' +
            '</div>';
    }

    function buildDashboard() {
        const panel = document.getElementById('dashboardPanel');
        if (!panel) return;

        // Collect all test blocks across all suites
        const allTests = Array.from(document.querySelectorAll('.test-block[id^="test-"]'));
        const total    = allTests.length;
        const docCount = allTests.filter(function (b) { return b.dataset.hasDoc === '1'; }).length;
        const docPct   = total > 0 ? Math.round(docCount / total * 100) : 0;

        // Tag frequency from data-tags attributes
        var tagFreq = Object.create(null);
        allTests.forEach(function (b) {
            try {
                JSON.parse(b.dataset.tags || '[]').forEach(function (t) {
                    if (t) tagFreq[t] = (tagFreq[t] || 0) + 1;
                });
            } catch (e) {}
        });
        var sortedTags     = Object.entries(tagFreq).sort(function (a, b) { return b[1] - a[1]; });
        var uniqueTagCount = Object.keys(tagFreq).length;

        // Suite breakdown — only depth-1 suites (direct children of root)
        var allSuiteBlocks  = Array.from(document.querySelectorAll('.suite-block[data-suite-depth]'));
        var depth1Suites    = allSuiteBlocks.filter(function (b) { return parseInt(b.dataset.suiteDepth, 10) === 1; });
        var totalSuiteCount = allSuiteBlocks.filter(function (b) { return parseInt(b.dataset.suiteDepth, 10) >= 1; }).length;

        // ── Build HTML ───────────────────────────────────────────────
        var html = '<div class="db-header">' +
            '<h2 class="db-title">Statistics Dashboard</h2>' +
            '<p class="db-subtitle">High-level overview of the entire test documentation</p>' +
            '</div>';

        // Stat cards
        html += '<div class="db-cards">' +
            dbCard('Total Tests',     String(total),     'accent') +
            dbCard('Documented',      docCount + ' <small>(' + docPct + '%)</small>', docPct >= 80 ? 'success' : 'accent',
                'Number of tests that contain a [Documentation] tag in their definition. Tests without documentation may be harder to understand at a glance.') +
            dbCard('Unique Tags',     String(uniqueTagCount), 'accent') +
            dbCard('Suites',          String(totalSuiteCount), 'accent') +
            '</div>';

        // Tag distribution bars
        if (sortedTags.length > 0) {
            var maxCount = sortedTags[0][1];
            html += '<div class="db-section">' +
                '<div class="db-section-title">Tag Distribution</div>' +
                '<div class="db-tag-bars">';
            sortedTags.forEach(function (entry) {
                var pct = Math.max(3, Math.round(entry[1] / maxCount * 100));
                html += '<div class="db-tag-row">' +
                    '<span class="db-tag-name">' + escHtml(entry[0]) + '</span>' +
                    '<div class="db-tag-bar-wrap"><div class="db-tag-bar" style="width:' + pct + '%"><span class="db-tag-count">' + entry[1] + '</span></div></div>' +
                    '</div>';
            });
            html += '</div></div>';
        }

        // Suite breakdown table (only when there are sub-suites)
        if (depth1Suites.length > 0) {
            html += '<div class="db-section">' +
                '<div class="db-section-title">Tests per Suite</div>' +
                '<table class="db-table"><thead><tr><th>Suite</th><th class="db-table-num">Tests</th></tr></thead><tbody>';;
            depth1Suites.forEach(function (b) {
                html += '<tr><td>' + escHtml(b.dataset.suiteName || '—') + '</td>' +
                    '<td class="db-table-num">' + escHtml(b.dataset.testCount || '0') + '</td></tr>';
            });
            html += '</tbody></table></div>';
        }

        panel.innerHTML = html;
    }

    function setupDashboardToggle() {
        var btn          = document.getElementById('dashboardToggle');
        var panel        = document.getElementById('dashboardPanel');
        var suiteContent = document.getElementById('suiteContent');
        var navTree      = document.querySelector('.nav-tree');
        var tagFilter    = document.getElementById('tagFilterPanel');
        if (!btn || !panel || !suiteContent) return;

        btn.addEventListener('click', function () {
            var isActive = btn.classList.contains('active');
            var testDetailPanel = document.getElementById('testDetailPanel');
            if (isActive) {
                btn.classList.remove('active');
                panel.style.display = 'none';
                if (testDetailPanel) testDetailPanel.style.display = 'none';
                suiteContent.style.display = '';
                if (navTree)   { navTree.removeAttribute('inert');   navTree.classList.remove('sidebar-disabled'); }
                if (tagFilter) { tagFilter.removeAttribute('inert'); tagFilter.classList.remove('sidebar-disabled'); }
            } else {
                buildDashboard();
                btn.classList.add('active');
                panel.style.display = '';
                suiteContent.style.display = 'none';
                if (testDetailPanel) testDetailPanel.style.display = 'none';
                if (navTree)   { navTree.setAttribute('inert', '');   navTree.classList.add('sidebar-disabled'); }
                if (tagFilter) { tagFilter.setAttribute('inert', ''); tagFilter.classList.add('sidebar-disabled'); }
            }
        });
    }

    /* =========================================================
       Test detail view (single-page per test case)
       ========================================================= */

    function showTestDetail(testBlock) {
        // Ensure the block is mounted before we try to clone it
        mountBlock(testBlock);

        var panel        = document.getElementById('testDetailPanel');
        var suiteContent = document.getElementById('suiteContent');
        var dashBtn      = document.getElementById('dashboardToggle');
        var dashPanel    = document.getElementById('dashboardPanel');
        if (!panel) return;

        // Deactivate dashboard if it was open
        if (dashBtn && dashBtn.classList.contains('active')) {
            dashBtn.classList.remove('active');
            if (dashPanel) dashPanel.style.display = 'none';
            var navTree   = document.querySelector('.nav-tree');
            var tagFilter = document.getElementById('tagFilterPanel');
            if (navTree)   { navTree.removeAttribute('inert');   navTree.classList.remove('sidebar-disabled'); }
            if (tagFilter) { tagFilter.removeAttribute('inert'); tagFilter.classList.remove('sidebar-disabled'); }
        }

        var testName  = testBlock.dataset.testName  || testBlock.id;
        var suiteName = testBlock.dataset.suiteName || '';
        var suiteId   = testBlock.dataset.suiteId   || '';

        // ── Build header ────────────────────────────────────────────
        var backBtn = suiteId
            ? '<button class="back-to-suite-btn" data-suite-target="' + escHtml(suiteId) + '" aria-label="Back to suite">'
                + '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="15 18 9 12 15 6"/></svg>'
                + 'Back to Suite'
                + '</button>'
            : '';

        var headerHtml = '<header class="content-header">'
            + '<div class="content-header-main">'
            + '<div class="content-breadcrumb">'
            + '<span class="breadcrumb-type">Test Case</span>';
        if (suiteName) {
            headerHtml += '<span class="breadcrumb-sep">in</span>'
                + '<span class="breadcrumb-suite">' + escHtml(suiteName) + '</span>';
        }
        headerHtml += '</div>'
            + '<h1 class="content-title-main">' + escHtml(testName) + '</h1>'
            + '</div>'
            + (backBtn ? '<div class="content-header-meta">' + backBtn + '</div>' : '')
            + '</header>';

        // ── Build wrapper (needs test-block class so kw-info buttons work) ──
        panel.innerHTML = '<div class="test-detail-inner test-block">' + headerHtml + '</div>';
        var wrapper = panel.querySelector('.test-detail-inner');

        // ── Clone the collapsible body sections ─────────────────────
        var collapsibleBody = testBlock.querySelector('.test-body-collapsible');
        if (collapsibleBody) {
            var bodyClone = collapsibleBody.cloneNode(true);
            bodyClone.style.display = '';

            // Remove the collapse toggle — show code directly in the detail view
            bodyClone.querySelectorAll('.code-wrapper').forEach(function (w) {
                var body = w.querySelector('.code-toggle-body');
                if (body) {
                    body.style.display = '';
                    w.parentNode.replaceChild(body, w);
                }
            });

            wrapper.appendChild(bodyClone);
        }

        if (suiteContent) suiteContent.style.display = 'none';
        panel.style.display = '';
        panel.scrollTop = 0;

        // ── Wire up the back-to-suite button ─────────────────────────
        var backBtnEl = panel.querySelector('.back-to-suite-btn');
        if (backBtnEl) {
            backBtnEl.addEventListener('click', function () {
                var target = this.dataset.suiteTarget;
                hideTestDetail();
                if (target) {
                    var link = document.querySelector('.tree-suite[data-suite-id="' + target + '"]');
                    if (link) link.click();
                }
            });
        }
    }

    function hideTestDetail() {
        var panel        = document.getElementById('testDetailPanel');
        var suiteContent = document.getElementById('suiteContent');
        var dashBtn      = document.getElementById('dashboardToggle');
        if (panel) panel.style.display = 'none';
        // Only restore suiteContent if the dashboard is not currently active
        if (!dashBtn || !dashBtn.classList.contains('active')) {
            if (suiteContent) suiteContent.style.display = '';
        }
    }

    /* =========================================================
       Tag filter
       ========================================================= */

    let activeTags = new Set();

    /** Build and show/update the results panel with all tests matching activeTags. */
    function applyTagFilter() {
        const resultPanel = document.getElementById('tagResultPanel');
        const resultBody  = document.getElementById('tagResultBody');
        const resultTitle = document.getElementById('tagResultTitle');
        const statusEl    = document.getElementById('tagFilterStatus');
        const clearBtn    = document.getElementById('tagFilterClear');

        if (clearBtn) clearBtn.style.display = activeTags.size > 0 ? '' : 'none';
        if (statusEl) statusEl.style.display = 'none';

        const backdrop = document.getElementById('tagResultBackdrop');

        if (activeTags.size === 0) {
            if (resultPanel) resultPanel.style.display = 'none';
            if (backdrop) backdrop.style.display = 'none';
            return;
        }

        // Collect all matching tests across ALL suites, grouped by suite name
        const allTests = Array.from(document.querySelectorAll('.test-block[id^="test-"]'));
        const groups   = Object.create(null); // suiteName -> [{name, id}]

        allTests.forEach(function (block) {
            let testTagSet;
            try { testTagSet = new Set(JSON.parse(block.dataset.tags || '[]')); } catch (e) { testTagSet = new Set(); }
            const hasMatch = Array.from(activeTags).some(function (t) { return testTagSet.has(t); });
            if (!hasMatch) return;
            const suite = block.dataset.suiteName || '—';
            if (!groups[suite]) groups[suite] = [];
            groups[suite].push({ name: block.dataset.testName || block.id, id: block.id });
        });

        const matchCount = Object.values(groups).reduce(function (s, arr) { return s + arr.length; }, 0);

        if (resultTitle) {
            resultTitle.textContent = matchCount + ' test' + (matchCount !== 1 ? 's' : '') +
                ' matching ' + activeTags.size + ' selected tag' + (activeTags.size !== 1 ? 's' : '');
        }

        if (resultBody) {
            var html = '';
            if (matchCount === 0) {
                html = '<div class="tag-result-empty">No tests match the selected tags.</div>';
            } else {
                Object.keys(groups).sort().forEach(function (suiteName) {
                    html += '<div class="tag-result-group">' +
                        '<div class="tag-result-group-name">' + escHtml(suiteName) + '</div>' +
                        '<ul class="tag-result-list">';
                    groups[suiteName].forEach(function (test) {
                        html += '<li><a class="tag-result-link" href="#' + escHtml(test.id) + '">' +
                            escHtml(test.name) + '</a></li>';
                    });
                    html += '</ul></div>';
                });
            }
            resultBody.innerHTML = html;

            // Clicking a link navigates to the test block (and closes the panel)
            resultBody.querySelectorAll('.tag-result-link').forEach(function (a) {
                a.addEventListener('click', function (e) {
                    e.preventDefault();
                    const target = document.getElementById(a.getAttribute('href').slice(1));
                    if (target) {
                        target.scrollIntoView({ behavior: 'smooth', block: 'center' });
                        target.classList.add('highlighted');
                        setTimeout(function () { target.classList.remove('highlighted'); }, 2000);
                    }
                });
            });
        }

        if (resultPanel) resultPanel.style.display = '';
        if (document.getElementById('tagResultBackdrop')) document.getElementById('tagResultBackdrop').style.display = '';
    }

    /** Collect all unique tags from all test blocks and render the filter panel. */
    function setupTagFilter() {
        const listEl = document.getElementById('tagFilterList');
        const panel  = document.getElementById('tagFilterPanel');
        if (!listEl || !panel) return;

        const allTags = new Set();
        document.querySelectorAll('.test-block[data-tags]').forEach(function (block) {
            try {
                JSON.parse(block.dataset.tags || '[]').forEach(function (t) { if (t) allTags.add(t); });
            } catch (e) {}
        });

        if (allTags.size === 0) {
            panel.style.display = 'none';
            return;
        }

        Array.from(allTags).sort().forEach(function (tag) {
            const btn = document.createElement('button');
            btn.className = 'tag-filter-btn';
            btn.textContent = tag;
            btn.dataset.tag = tag;
            btn.addEventListener('click', function () {
                if (activeTags.has(tag)) {
                    activeTags.delete(tag);
                    btn.classList.remove('active');
                } else {
                    activeTags.add(tag);
                    btn.classList.add('active');
                }
                applyTagFilter();
            });
            listEl.appendChild(btn);
        });

        const clearBtn = document.getElementById('tagFilterClear');
        if (clearBtn) {
            clearBtn.style.display = 'none';
            clearBtn.addEventListener('click', function () {
                activeTags.clear();
                listEl.querySelectorAll('.tag-filter-btn.active').forEach(function (b) {
                    b.classList.remove('active');
                });
                applyTagFilter();
            });
        }
        const statusEl = document.getElementById('tagFilterStatus');
        if (statusEl) statusEl.style.display = 'none';

        // Close button for the results panel
        const closeBtn = document.getElementById('tagResultClose');
        if (closeBtn) {
            closeBtn.addEventListener('click', function () {
                const resultPanel = document.getElementById('tagResultPanel');
                if (resultPanel) resultPanel.style.display = 'none';
                const backdrop = document.getElementById('tagResultBackdrop');
                if (backdrop) backdrop.style.display = 'none';
                // also deselect all active tags
                activeTags.clear();
                listEl.querySelectorAll('.tag-filter-btn.active').forEach(function (b) {
                    b.classList.remove('active');
                });
                if (clearBtn) clearBtn.style.display = 'none';
            });
        }

        // Clicking the backdrop also closes the panel
        const backdropEl = document.getElementById('tagResultBackdrop');
        if (backdropEl) {
            backdropEl.addEventListener('click', function () {
                const resultPanel = document.getElementById('tagResultPanel');
                if (resultPanel) resultPanel.style.display = 'none';
                backdropEl.style.display = 'none';
                activeTags.clear();
                listEl.querySelectorAll('.tag-filter-btn.active').forEach(function (b) {
                    b.classList.remove('active');
                });
                if (clearBtn) clearBtn.style.display = 'none';
            });
        }
    }

    /* =========================================================
       Highlight helpers
       ========================================================= */

    function clearTestHighlight() {
        testBlocks.forEach(function (block) { block.classList.remove('highlighted'); });
    }

    /* =========================================================
       Initialisation
       ========================================================= */

    // Hide all branches by default (CSS already does, but hidden improves a11y)
    document.querySelectorAll('.tree-children').forEach(function (ul) {
        ul.hidden = true;
    });

    // Show the suite that is initially active (or the first suite)
    const initiallyActive = document.querySelector('.tree-suite.active') || document.querySelector('.tree-suite');
    if (initiallyActive) {
        applySuiteFilter(initiallyActive.dataset.suiteId);
        // Expand its immediate children to avoid an empty-looking tree on load.
        setBranchExpanded(initiallyActive, true);
    }
    prepareLazyRenderingForCurrentSuite();
    setupTagFilter();
    applyTagFilter();
    setupDashboardToggle();

    /* =========================================================
       Tree navigation (delegated)
       ========================================================= */

    if (navRoot) {
        navRoot.addEventListener('click', function (e) {
            const link = e.target.closest('.tree-suite, .tree-test');
            if (!link) return;
            e.preventDefault();

            const isSuite = link.classList.contains('tree-suite');
            const targetId = link.dataset.target;
            const suiteId  = link.dataset.suiteId;

            // Toggle expand/collapse only for suite links that actually have children
            if (isSuite && findChildUl(link)) {
                const li = link.closest('li');
                const expandedNow = !(li && li.classList.contains('expanded'));
                setBranchExpanded(link, expandedNow);
            }

            setActiveTreeLink(link);

            if (isSuite) {
                // Suite selected: hide test detail, show suite content
                hideTestDetail();
                applySuiteFilter(suiteId);
                prepareLazyRenderingForCurrentSuite();
                applyTagFilter();
                scrollToTarget(targetId, false);
            } else {
                // Test selected: show dedicated single-page detail view
                const block = document.getElementById(targetId);
                if (block) showTestDetail(block);
            }
        });
    }

    /* =========================================================
       Main content interactions (delegated)
       ========================================================= */

    // Sub-suite rows: delegate click to matching sidebar tree link
    document.addEventListener('click', function (e) {
        const el = e.target.closest('.subsuite-link');
        if (!el) return;
        e.preventDefault();
        const suiteId = el.dataset.suiteId;
        if (!suiteId) return;
        const treeLink = document.querySelector('.tree-suite[data-suite-id="' + suiteId + '"]');
        if (treeLink) treeLink.click();
    });

    // Test list row click → open single-page detail view
    document.addEventListener('click', function (e) {
        const row = e.target.closest('.test-list-row');
        if (!row) return;
        const targetId = row.dataset.target;
        if (!targetId) return;
        const block = document.getElementById(targetId);
        if (!block) return;
        const treeLink = document.querySelector('.tree-test[data-target="' + targetId + '"]');
        if (treeLink) setActiveTreeLink(treeLink);
        showTestDetail(block);
    });

    /* =========================================================
       Collapsible code sections
       ========================================================= */

    // Collapse all code sections by default
    document.querySelectorAll('.code-wrapper').forEach(function (wrapper) {
        wrapper.classList.add('collapsed');
        const body = wrapper.querySelector('.code-toggle-body');
        if (body) body.style.display = 'none';
    });
    document.querySelectorAll('.code-toggle').forEach(function (toggle) {
        toggle.classList.add('collapsed');
    });

    // Delegate toggle clicks to avoid binding issues with dynamically mounted content
    document.addEventListener('click', function (e) {
        const toggle = e.target.closest('.code-toggle');
        if (!toggle) return;

        const wrapper = toggle.closest('.code-wrapper');
        if (wrapper) {
            const isCollapsed = wrapper.classList.toggle('collapsed');
            toggle.classList.toggle('collapsed', isCollapsed);
            const body = wrapper.querySelector('.code-toggle-body');
            if (body) body.style.display = isCollapsed ? 'none' : '';
        }
    });

    /* =========================================================
       Robot Framework client-side syntax highlighter
       (used for pre.rf-code elements as a fallback)
       ========================================================= */

    /** Escape HTML special characters. */
    function rfEscape(html) {
        return html.replace(/[&<>]/g, function (ch) {
            if (ch === '&') return '&amp;';
            if (ch === '<') return '&lt;';
            return '&gt;';
        });
    }

    /** Wrap RF variable expressions (${...}, @{...}, etc.) in a span. */
    function renderVariables(raw) {
        const RE_VAR = /(\$\{[^}]+\}|@\{[^}]+\}|&\{[^}]+\}|%\{[^}]+\})/g;
        let result = '';
        let last = 0;
        let match;
        while ((match = RE_VAR.exec(raw)) !== null) {
            if (match.index > last) result += rfEscape(raw.slice(last, match.index));
            result += '<span class="rf-var">' + rfEscape(match[1]) + '</span>';
            last = RE_VAR.lastIndex;
        }
        if (last < raw.length) result += rfEscape(raw.slice(last));
        return result;
    }

    /**
     * Highlight the "tail" portion of a keyword line:
     * handles quoted strings and variable expressions.
     */
    function highlightTail(rawTail) {
        const RE_QUOTE = /("[^"\n]*"|'[^'\n]*')/g;
        let match;
        let last = 0;
        const parts = [];

        while ((match = RE_QUOTE.exec(rawTail)) !== null) {
            if (match.index > last) parts.push({ type: 'plain', value: rawTail.slice(last, match.index) });
            parts.push({ type: 'quote', value: match[0] });
            last = RE_QUOTE.lastIndex;
        }
        if (last < rawTail.length) parts.push({ type: 'plain', value: rawTail.slice(last) });

        let out = '';
        for (const part of parts) {
            if (part.type === 'quote') {
                const inner    = part.value.slice(1, -1);
                const quoteChar = part.value[0];
                out += '<span class="rf-string">'
                    + rfEscape(quoteChar)
                    + renderVariables(inner)
                    + rfEscape(quoteChar)
                    + '</span>';
            } else {
                out += renderVariables(part.value);
            }
        }

        // Highlight assignment operator
        out = out.replace(/\s=\s/g, ' <span class="rf-assign">=<\/span> ');
        return out;
    }

    /** Apply syntax highlighting to a single `pre.rf-code` element. */
    function highlightRfPre(pre) {
        if (pre.dataset.highlighted === '1') return;

        const lines = pre.textContent.split(/\r?\n/);
        const out   = [];

        lines.forEach(function (raw, index) {
            const escaped = rfEscape(raw);
            const trimmed = raw.trim();

            // Line 0: section header  *** ... ***
            if (index === 0 && /^\*\*\*.*\*\*\*$/.test(trimmed)) {
                out.push('<span class="rf-header">' + escaped + '</span>');
                return;
            }

            // Line 1: test / keyword name
            if (index === 1) {
                out.push('<span class="rf-testname">' + escaped + '</span>');
                return;
            }

            // Comment lines
            if (/^\s*#/.test(raw)) {
                out.push('<span class="rf-comment">' + escaped + '</span>');
                return;
            }

            // Keyword + arguments
            const match = raw.match(/^(\s*)(\S.*?)(?=(\s{2,}|$))/);
            if (match) {
                const indent  = match[1];
                const headRaw = match[2];
                const tailRaw = raw.slice(match[0].length);
                out.push(indent + '<span class="rf-keyword">' + rfEscape(headRaw) + '</span>' + highlightTail(tailRaw));
            } else {
                out.push(highlightTail(raw));
            }
        });

        pre.innerHTML = out.join('\n');
        pre.dataset.highlighted = '1';
    }

    /** Add line numbers to a Pygments-highlighted pre.robotframework element. */
    function addLineNumbers(pre) {
        if (pre.dataset.lineNumbers === '1') return;
        const codeEl = pre.querySelector('code') || pre;
        const lines = codeEl.innerHTML.split('\n');
        // Remove the trailing empty line Pygments appends
        if (lines.length > 0 && lines[lines.length - 1].trim() === '') {
            lines.pop();
        }
        codeEl.innerHTML = lines.map(function (line) {
            return '<span class="rf-line">' + line + '</span>';
        }).join('');
        pre.dataset.lineNumbers = '1';

        // PoC: enrich keyword call lines with an info button (if metadata exists)
        enhanceKeywordInfo(pre);
    }

    /* =========================================================
       PoC: Keyword documentation (info buttons + dialog)
       ========================================================= */

    function getKwDocIndexForPre(pre) {
        const testBlock = pre.closest('.test-block') || pre.closest('.suite-fixture-block');
        if (!testBlock) return null;
        if (testBlock._kwDocIndex instanceof Map) return testBlock._kwDocIndex;

        const ndjsonEl = testBlock.querySelector('script.kw-doc-ndjson');
        if (!ndjsonEl) return null;

        const map = new Map();
        // Be tolerant: if JSON objects were concatenated ("}{"), split them.
        const text = (ndjsonEl.textContent || '').replace(/}\s*{/g, '}\n{');
        const raw = text.split(/\r?\n/);
        raw.forEach(function (line) {
            const trimmed = (line || '').trim();
            if (!trimmed) return;
            try {
                const obj = JSON.parse(trimmed);
                if (obj && obj.name && !map.has(obj.name)) {
                    map.set(obj.name, obj);
                }
            } catch (e) {
                // Ignore malformed lines; NDJSON is best-effort.
            }
        });
        testBlock._kwDocIndex = map;
        return map;
    }

    function extractKeywordInfoFromLine(lineEl) {
        if (!lineEl) return null;

        // Regular keyword call line: Pygments uses .nf for KEYWORD tokens.
        const nf = lineEl.querySelector('span.nf');
        if (nf) {
            const name = (nf.textContent || '').trim();
            if (!name) return null;
            return { name: name, anchor: nf };
        }

        // Setup/Teardown lines: keyword may be tokenised as .n following a .py [Setup]/[Teardown]
        const py = lineEl.querySelector('span.py');
        if (py) {
            const label = (py.textContent || '').trim();
            if (label === '[Setup]' || label === '[Teardown]') {
                const spans = Array.from(lineEl.querySelectorAll('span'));
                const startIdx = spans.indexOf(py);
                for (let i = startIdx + 1; i < spans.length; i++) {
                    const s = spans[i];
                    if (!s || !s.classList) continue;
                    if (s.classList.contains('nf') || s.classList.contains('n')) {
                        const name = (s.textContent || '').trim();
                        if (!name) return null;
                        return { name: name, anchor: s };
                    }
                }
            }
        }

        return null;
    }

    function enhanceKeywordInfo(pre) {
        if (!pre || pre.dataset.kwInfo === '1') return;
        const index = getKwDocIndexForPre(pre);
        if (!index || index.size === 0) {
            pre.dataset.kwInfo = '1';
            return;
        }

        const codeEl = pre.querySelector('code') || pre;
        const lineEls = codeEl.querySelectorAll('.rf-line');
        lineEls.forEach(function (lineEl) {
            // Avoid duplicating buttons on reruns.
            if (lineEl.querySelector('.kw-info-btn')) return;

            const info = extractKeywordInfoFromLine(lineEl);
            if (!info || !info.name) return;

            const meta = index.get(info.name);
            if (!meta || !meta.doc) return;

            const btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'kw-info-btn';
            btn.dataset.kwName = info.name;
            btn.setAttribute('aria-label', 'Show keyword documentation: ' + info.name);
            btn.title = 'Show Keyword Documentation';
            btn.textContent = 'Show Keyword Documentation';

            // Append to the line and let CSS place it on the far right.
            lineEl.appendChild(btn);
        });

        pre.dataset.kwInfo = '1';
    }

    function ensureKwDialog() {
        let dlg = document.getElementById('kwDocDialog');
        if (dlg) return dlg;

        dlg = document.createElement('dialog');
        dlg.id = 'kwDocDialog';
        dlg.className = 'kw-doc-dialog';
        dlg.innerHTML =
            '<form method="dialog" class="kw-doc-dialog-inner">'
                + '<header class="kw-doc-dialog-header">'
                    + '<div class="kw-doc-dialog-title">'
                        + '<div class="kw-doc-name" id="kwDocName"></div>'
                        + '<div class="kw-doc-owner" id="kwDocOwner"></div>'
                    + '</div>'
                    + '<button class="kw-doc-close" value="close" aria-label="Close">'
                        + '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'
                            + '<line x1="18" y1="6" x2="6" y2="18"></line>'
                            + '<line x1="6" y1="6" x2="18" y2="18"></line>'
                        + '</svg>'
                    + '</button>'
                + '</header>'
                + '<section class="kw-doc-dialog-body">'
                    + '<div class="kw-doc-args" id="kwDocArgs"></div>'
                    + '<pre class="kw-doc-text" id="kwDocText"></pre>'
                + '</section>'
            + '</form>';

        document.body.appendChild(dlg);
        return dlg;
    }

    function openKwDialog(meta, triggerBtn) {
        const dlg = ensureKwDialog();
        dlg._kwTriggerBtn = triggerBtn || null;

        const nameEl = dlg.querySelector('#kwDocName');
        const ownerEl = dlg.querySelector('#kwDocOwner');
        const argsEl = dlg.querySelector('#kwDocArgs');
        const textEl = dlg.querySelector('#kwDocText');

        const kwName = (meta && meta.name) ? meta.name : '';
        const owner = (meta && meta.owner) ? meta.owner : '';
        const doc = (meta && meta.doc) ? meta.doc : '';
        const args = (meta && meta.args) ? meta.args : [];

        if (nameEl) nameEl.textContent = kwName;
        if (ownerEl) ownerEl.textContent = owner ? ('Owner: ' + owner) : '';

        if (textEl) textEl.textContent = doc;

        try {
            if (!dlg.open) dlg.showModal();
        } catch (e) {
            // If <dialog> is unsupported, fall back to toggling the open attribute.
            dlg.setAttribute('open', '');
        }
    }

    // Close behavior: return focus to the triggering info button.
    document.addEventListener('close', function (e) {
        const dlg = e.target;
        if (!dlg || dlg.id !== 'kwDocDialog') return;
        const btn = dlg._kwTriggerBtn;
        dlg._kwTriggerBtn = null;
        if (btn && typeof btn.focus === 'function') {
            try { btn.focus(); } catch (err) {}
        }
    }, true);

    // Delegate info button clicks.
    document.addEventListener('click', function (e) {
        const btn = e.target.closest('.kw-info-btn');
        if (!btn) return;

        // Prevent test-block click handlers from triggering.
        e.preventDefault();
        e.stopPropagation();

        const pre = btn.closest('pre.robotframework');
        if (!pre) return;
        const index = getKwDocIndexForPre(pre);
        if (!index) return;

        const kwName = btn.dataset.kwName;
        if (!kwName) return;
        const meta = index.get(kwName);
        if (!meta) return;

        openKwDialog(meta, btn);
    });

    // Apply to any pre.rf-code / pre.robotframework elements already in the DOM
    document.querySelectorAll('pre.rf-code').forEach(highlightRfPre);
    document.querySelectorAll('pre.robotframework').forEach(addLineNumbers);
});
